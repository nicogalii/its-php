<!-- Inclusione del file config.php -->
<?php include './config/config.php'; ?>

<!-- Inclusione del file header.php -->
<?php include './views/header.php'; ?>

<!-- Inclusione del file menu.php -->
<?php include './views/menu.php'; ?>

<!-- Inclusione del file content.php -->
<?php include './views/content.php'; ?>

<!-- Inclusione del file footer.php -->
<?php include './views/footer.php'; ?>
<div id="home">
    <h2 class="titolo"></h2>
    <div><img src="https://img.pokemondb.net/artwork/avif/pikachu.avif" alt="" class="foto_copertina"></div>
</div>
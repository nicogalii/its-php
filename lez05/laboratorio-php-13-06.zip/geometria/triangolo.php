<?php

class Triangolo
{
}

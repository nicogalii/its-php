<?php

function strLength($string)
{
    return strlen($string);
}

echo strLength(("Hello, World!"));
<?php

$currentDateTime = date('Y-m-d H:i-s');
echo $currentDateTime;
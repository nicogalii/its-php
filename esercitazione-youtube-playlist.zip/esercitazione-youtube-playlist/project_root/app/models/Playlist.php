<?php

namespace App\Models;

class Playlist
{
    // Codice della classe Playlist
}

<!-- <h2><?= basename(__FILE__); ?></h2> -->
<script src="./js/script.js"></script>
</body>

</html>
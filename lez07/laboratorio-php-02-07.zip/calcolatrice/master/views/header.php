<!-- <?php echo __FILE__; ?> -->

<!-- <h2><?= basename(__FILE__); ?></h2> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="author" content="Valentin Sorohan">
    <meta name="description" content="">
    <title><?= TITOLO_SITO; ?></title>
    <link rel="stylesheet" href="./css/style.css">
</head>

<body>
    <h1><?= TITOLO_SITO; ?></h1>
<!-- inizio sessione -->
<?php include "./config/config.php"; ?>

<!-- inclusione del file header.php -->
<?php
include "./views/header.php";
?>

<!-- inclusione del file menu.php -->
<?php
// include "./views/menu.php";
?>

<!-- inclusione del file header.php -->
<?php
include "./views/content.php";
?>

<!-- inclusione del file footer.php -->
<?php
include "./views/footer.php";
?>
<?php
/*
Esercizio 1: Hello World
Scrivi uno script PHP che stampa "Hello, World!" sullo schermo.
*/

echo 'Hello World';

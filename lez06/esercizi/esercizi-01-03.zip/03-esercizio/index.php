<?php
/*
Esercizio 3: Condizioni
Scrivi uno script PHP che controlla se una variabile numerica è positiva, negativa o zero e stampa un messaggio appropriato.
*/

$a = 2;

if ($a = 0) {
    echo 'Il numero è 0';
} else if ($a > 0) {
    echo 'Il numero è positivo';
} else {
    echo 'Il numero è negativo ';
}

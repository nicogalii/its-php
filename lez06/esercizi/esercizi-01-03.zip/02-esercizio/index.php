<?php
/*
Esercizio 2: Variabili e Operazioni Aritmetiche
Crea uno script PHP che dichiara due variabili numeriche e stampa la somma, la differenza, il prodotto e il quoziente.
*/

$a = 4;
$b = 10;

$somma = $a + $b;
$differenza = $a - $b;
$prodotto = $a * $b;
$quoziente = $a / $b;

echo 'La somma è: ' . $somma . '<br>';
echo 'La differenza è: ' . $differenza . '<br>';
echo 'La prodotto è: ' . $prodotto . '<br>';
echo 'La quoziente è: ' . $quoziente . '<br>';

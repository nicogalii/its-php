<?php
// Faccio partire l'istruzione      
session_start(); // Spazio di memoria sul server

define('TITOLO_SITO', 'Pokemon');

<a href="?page=home" class="" title="">Home</a>
<a href="?page=gallery" class="" title="">Gallery</a>